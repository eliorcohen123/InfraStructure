package elior.com.infrastructure.RoomSearchPackage;

import com.eliorcohen123456.locationprojectroom.DataAppPackage.PlaceModel;

import java.util.ArrayList;

public interface IPlacesDataReceived {

    void onPlacesDataReceived(ArrayList<PlaceModel> results_);
}
